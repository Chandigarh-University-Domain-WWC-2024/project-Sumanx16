import React, { useState } from 'react';
import { Shield } from 'lucide-react';
import { ThreatAssessment, ThreatCategory, RiskLevel, Priority, ThreatStatus } from './types';
import { Dashboard } from './components/Dashboard';
import { ThreatCard } from './components/ThreatCard';

// Sample data - in a real app, this would come from an API
const mockThreats: ThreatAssessment[] = [
  {
    id: '1',
    title: 'Advanced Persistent Threat Detection',
    description: 'Multiple unauthorized access attempts detected from known malicious IP ranges, indicating a potential state-sponsored cyber attack.',
    category: ThreatCategory.CYBER,
    riskLevel: RiskLevel.CRITICAL,
    priority: Priority.IMMEDIATE,
    timestamp: new Date().toISOString(),
    status: ThreatStatus.ACTIVE,
    aiConfidence: 95
  },
  {
    id: '2',
    title: 'Infrastructure Vulnerability',
    description: 'Critical infrastructure systems showing signs of potential compromise. Multiple security layers may be affected.',
    category: ThreatCategory.PHYSICAL,
    riskLevel: RiskLevel.HIGH,
    priority: Priority.HIGH,
    timestamp: new Date().toISOString(),
    status: ThreatStatus.MONITORING,
    aiConfidence: 88
  },
  {
    id: '3',
    title: 'Social Engineering Campaign',
    description: 'Coordinated disinformation campaign detected across multiple social media platforms targeting critical infrastructure.',
    category: ThreatCategory.SOCIAL,
    riskLevel: RiskLevel.MEDIUM,
    priority: Priority.MEDIUM,
    timestamp: new Date().toISOString(),
    status: ThreatStatus.ACTIVE,
    aiConfidence: 82
  }
];

function App() {
  const [threats] = useState<ThreatAssessment[]>(mockThreats);
  const [selectedThreat, setSelectedThreat] = useState<ThreatAssessment | null>(null);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center">
            <Shield className="w-10 h-10 text-blue-600" />
            <div className="ml-4">
              <h1 className="text-3xl font-bold text-gray-900">
                National Security Threat Assessment
              </h1>
              <p className="text-gray-600">
                AI-Powered Threat Analysis and Response System
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Dashboard threats={threats} />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {threats.map(threat => (
            <ThreatCard
              key={threat.id}
              threat={threat}
              onClick={setSelectedThreat}
            />
          ))}
        </div>

        {selectedThreat && (
          <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center">
            <div className="bg-white rounded-lg shadow-xl p-8 max-w-2xl w-full m-4">
              <h2 className="text-2xl font-bold mb-4">{selectedThreat.title}</h2>
              <p className="text-gray-600 mb-4">{selectedThreat.description}</p>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <p className="text-sm text-gray-600">Category</p>
                  <p className="font-medium">{selectedThreat.category}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Risk Level</p>
                  <p className="font-medium">{selectedThreat.riskLevel}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Priority</p>
                  <p className="font-medium">{selectedThreat.priority}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Status</p>
                  <p className="font-medium">{selectedThreat.status}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedThreat(null)}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;