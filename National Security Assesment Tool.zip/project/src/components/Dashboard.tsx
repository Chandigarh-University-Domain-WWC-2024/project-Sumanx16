import React from 'react';
import { BarChart3, Shield, AlertTriangle, Activity } from 'lucide-react';
import { ThreatAssessment, RiskLevel } from '../types';

interface DashboardProps {
  threats: ThreatAssessment[];
}

export const Dashboard: React.FC<DashboardProps> = ({ threats }) => {
  const criticalThreats = threats.filter(t => t.riskLevel === RiskLevel.CRITICAL).length;
  const highThreats = threats.filter(t => t.riskLevel === RiskLevel.HIGH).length;
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center">
          <Shield className="w-8 h-8 text-blue-600" />
          <div className="ml-4">
            <p className="text-sm font-medium text-gray-600">Total Threats</p>
            <p className="text-2xl font-semibold text-gray-900">{threats.length}</p>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center">
          <AlertTriangle className="w-8 h-8 text-red-600" />
          <div className="ml-4">
            <p className="text-sm font-medium text-gray-600">Critical Threats</p>
            <p className="text-2xl font-semibold text-gray-900">{criticalThreats}</p>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center">
          <Activity className="w-8 h-8 text-orange-600" />
          <div className="ml-4">
            <p className="text-sm font-medium text-gray-600">High Priority</p>
            <p className="text-2xl font-semibold text-gray-900">{highThreats}</p>
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6">
        <div className="flex items-center">
          <BarChart3 className="w-8 h-8 text-green-600" />
          <div className="ml-4">
            <p className="text-sm font-medium text-gray-600">AI Analysis</p>
            <p className="text-2xl font-semibold text-gray-900">
              {Math.round(threats.reduce((acc, t) => acc + t.aiConfidence, 0) / threats.length)}%
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}