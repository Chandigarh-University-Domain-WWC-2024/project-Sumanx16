import React from 'react';
import { Shield, AlertTriangle, Activity, Clock } from 'lucide-react';
import { ThreatAssessment, RiskLevel } from '../types';

interface ThreatCardProps {
  threat: ThreatAssessment;
  onClick: (threat: ThreatAssessment) => void;
}

const getRiskColor = (risk: RiskLevel) => {
  switch (risk) {
    case RiskLevel.CRITICAL:
      return 'bg-red-100 text-red-800';
    case RiskLevel.HIGH:
      return 'bg-orange-100 text-orange-800';
    case RiskLevel.MEDIUM:
      return 'bg-yellow-100 text-yellow-800';
    case RiskLevel.LOW:
      return 'bg-green-100 text-green-800';
  }
};

export const ThreatCard: React.FC<ThreatCardProps> = ({ threat, onClick }) => {
  return (
    <div 
      className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow cursor-pointer"
      onClick={() => onClick(threat)}
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center">
          <Shield className="w-6 h-6 text-blue-600 mr-2" />
          <h3 className="text-lg font-semibold text-gray-900">{threat.title}</h3>
        </div>
        <span className={`px-3 py-1 rounded-full text-sm font-medium ${getRiskColor(threat.riskLevel)}`}>
          {threat.riskLevel}
        </span>
      </div>
      
      <p className="text-gray-600 mb-4 line-clamp-2">{threat.description}</p>
      
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center">
          <AlertTriangle className="w-4 h-4 text-gray-500 mr-1" />
          <span className="text-gray-600">{threat.category}</span>
        </div>
        
        <div className="flex items-center">
          <Activity className="w-4 h-4 text-gray-500 mr-1" />
          <span className="text-gray-600">{threat.status}</span>
        </div>
        
        <div className="flex items-center">
          <Clock className="w-4 h-4 text-gray-500 mr-1" />
          <span className="text-gray-600">
            {new Date(threat.timestamp).toLocaleDateString()}
          </span>
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">AI Confidence</span>
          <div className="w-2/3 bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-600 rounded-full h-2"
              style={{ width: `${threat.aiConfidence}%` }}
            />
          </div>
          <span className="text-sm font-medium text-gray-900">
            {threat.aiConfidence}%
          </span>
        </div>
      </div>
    </div>
  );
}