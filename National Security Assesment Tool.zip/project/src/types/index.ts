export interface ThreatAssessment {
  id: string;
  title: string;
  description: string;
  category: ThreatCategory;
  riskLevel: RiskLevel;
  priority: Priority;
  timestamp: string;
  status: ThreatStatus;
  aiConfidence: number;
}

export enum ThreatCategory {
  CYBER = 'Cyber',
  PHYSICAL = 'Physical',
  SOCIAL = 'Social',
  ECONOMIC = 'Economic',
  ENVIRONMENTAL = 'Environmental'
}

export enum RiskLevel {
  CRITICAL = 'Critical',
  HIGH = 'High',
  MEDIUM = 'Medium',
  LOW = 'Low'
}

export enum Priority {
  IMMEDIATE = 'Immediate',
  HIGH = 'High',
  MEDIUM = 'Medium',
  LOW = 'Low'
}

export enum ThreatStatus {
  ACTIVE = 'Active',
  MONITORING = 'Monitoring',
  MITIGATED = 'Mitigated',
  RESOLVED = 'Resolved'
}